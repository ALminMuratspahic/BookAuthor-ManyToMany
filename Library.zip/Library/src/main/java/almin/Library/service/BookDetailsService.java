package almin.Library.service;

import almin.Library.model.BookDetails;
import almin.Library.repositroy.BookDetailsRepo;
import almin.Library.repositroy.BookRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.awt.print.Book;
import java.util.Optional;

@Service
public class BookDetailsService {
    @Autowired
    private BookRepo bookRepo;
    @Autowired
    private BookDetailsRepo bookDetailsRepo;

    public void saveDetails(BookDetails bookDetails){
        bookDetailsRepo.save(bookDetails);
    }

    public void deleteBookDetails(BookDetails bookDetails){
        bookDetailsRepo.delete(bookDetails);
    }


}
